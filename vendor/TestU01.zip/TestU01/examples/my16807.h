#include "unif01.h"

unif01_Gen *CreateMy16807 (int s);

void DeleteMy16807 (unif01_Gen * gen);
